# Block IP Addresses
Block specific IP addresses from visiting a page on your website.</br>
Edit blocked_ips.txt to add one IP address per line.
