<?php

echo "Your IP address (" . $_SERVER['REMOTE_ADDR'] . ") has been banned from visiting this page.";

?>
